#!/bin/bash
pyside6-lrelease *.ts
